package com.peisia.board;

public class Post {
	//제목, 내용, id, no 필드 추가
	String title;
	String content;
	String id;
	int no;

	Post(){
		
	}
	Post(String t,String c,String i,int n){
		title = t;
		content = c;
		id = i;
		no = n;
	}
	
}
