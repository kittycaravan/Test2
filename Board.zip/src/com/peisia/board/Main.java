package com.peisia.board;

// ctrl + shift + o : 자동 임포트
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		ArrayList<Post> posts = new ArrayList<>();
		//Post 객체 ( 즉, 글 ) 3개 정도 생성
//		Post p =new Post();
//		p.id="a";
//		p.title="b";
//		p.content="글내용...";
//		p.no = 1;
		
		Post p =new Post("제목테스트1","내용테스트1","테스터1",1);
		posts.add(p);
		Post p2 =new Post("제목테스트2","내용테스트2","테스터2",1);
		posts.add(p2);
		Post p3 =new Post("제목테스트3","내용테스트3","테스터3",1);
		posts.add(p3);
		
//		posts.add(new Post("제목테스트3","내용테스트3","테스터3",1));

		Scanner sc = new Scanner(System.in);
		System.out.println("명령어를 입력해주세요. [2:글 리스트]");
		String cmd = sc.next();
		switch(cmd) {
		case "1":
			break;
		case "2":	// 글 리스트 보여주기
			for(int i=0;i<posts.size();i=i+1) {
				int no = posts.get(i).no;
				System.out.print(no);
				System.out.print("  ");
				String title = posts.get(i).title;
				System.out.print(title);
				System.out.print("  ");
				String id = posts.get(i).id;
				System.out.print(id);
				System.out.println();
			}
			break;
		case "e":
			break;
		}
		
		
	}
}
